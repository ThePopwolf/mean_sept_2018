const products = require('../controllers/products_controller.js'),
      mongoose = require('mongoose'),
      Product = mongoose.model('Product');

module.exports = function(app) {
  app.get('/api/products', products.index);
  app.get('/api/products/:id', products.show);
  app.post('/api/products', products.create);
  app.put('/api/products/:id/edit', products.update);
  app.delete('/api/products/:id/remove', products.destroy);
  app.all('*', products.all);
}
