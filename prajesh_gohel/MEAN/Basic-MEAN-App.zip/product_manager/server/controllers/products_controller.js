const path = require('path'),
      Product = require('../models/products.js');

module.exports = {
  index: function(req, res) {
    return res.json({ sample: "sample" });
  },

  show: function(req, res) {
    return res.json({ sample: "sample" });
  },

  create: function(req, res) {
    return res.json({ sample: "sample" });
  },

  update: function(req, res) {
    return res.json({ sample: "sample" });
  },

  destroy: function(req, res) {
    return res.json({ sample: "sample" });
  },

  all: function(req, res, next) {
    res.sendFile(path.resolve("./public/dist/public/index.html"));
  }
}
